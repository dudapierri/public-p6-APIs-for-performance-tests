from django.apps import AppConfig


class Api1Config(AppConfig):
    name = "apps.api"
